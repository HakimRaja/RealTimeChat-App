const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose");
const userRoute = require("./Routes/userRoutes")
const chatRouter = require("./Routes/chatRoute")
const messageRouter = require("./Routes/messageRoute")
const app = express();
require("dotenv").config(); //configurign env file
const port = process.env.port || 5000
const uri = process.env.ATLAS_URI;

app.use(express.json());

app.use(cors());

app.use("/api/users", userRoute);
app.use('/api/chats',chatRouter);
app.use('/api/messages',messageRouter);
app.get("/", (req , res)=>{
    try {
        return res.status(200).send("Hello World!");
    } catch (error) {
        return res.status(505).send(error.message);
    }
})

app.listen(port , (req,res)=>{
    console.log(`Server is running on port: ${port}`)
    mongoose.connect(uri).then(()=>{
        console.log("MongoDB connection eshtablished")
    }).catch((error)=>{
        console.log("MongoDB connection failed :" ,error.message)
    });
})
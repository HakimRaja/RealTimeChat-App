// createChat api
// getuserChats
//find a certain chat
const chatModel = require('../Models/chatModel');

const createChat=async(req,res) =>{//in req we have ids of both users without any specific order
    const {firstId , secondId} = req.body;
    try {
        const chat = await chatModel.findOne({
            members : {$all : [firstId , secondId]}
        })//check if chat is already made

        if(chat) 
            return res.status(200).json(chat);

        const newChat = new chatModel({
            members: [firstId, secondId]
        });
        const response = await newChat.save();

        return res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
        return res.status(400).send(error.message)
    }
}

const findUserChats = async (req,res)=>{//req will have id of logged in user
    const userId = req.params.userId;

    try {
        const chats = await chatModel.find({
            members: {$in : [userId]}
        })
        return res.status(200).json(chats);
    } catch (error) {
        console.log(error.message);
        return res.status(400).send(error.message)
    }
}

const findChat = async (req,res)=>{//req will have id of logged in user
    const {firstId, secondId} = req.params;

    try {
        const chat = await chatModel.findOne({
            members: {$all : [firstId , secondId]}
        })
        return res.status(200).json(chat);
    } catch (error) {
        console.log(error.message);
        return res.status(400).send(error.message)
    }
}

module.exports = {findChat,findUserChats,createChat}

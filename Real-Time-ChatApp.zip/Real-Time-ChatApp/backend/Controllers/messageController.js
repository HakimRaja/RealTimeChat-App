const messageModel = require("../Models/messageModel");

//creating meessages

const createMessage = async(req,res) => {
    const {chatId, senderId, text} = req.body;

    const message = new messageModel({
        chatId , senderId , text
    })
    try {
        const response = await message.save();
        return res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
        return res.status(400).send(error.message);
    }
}

//getmessages
const getMessages = async(req,res)=>{
    const {chatId} = req.params;
    try {
        const messages = await messageModel.find({chatId});
        return res.status(200).json(messages); // ✅ send the response!
    } catch (error) {
        console.log(error.message);
        return res.status(400).send(error.message);
    }
}


module.exports = {createMessage , getMessages};
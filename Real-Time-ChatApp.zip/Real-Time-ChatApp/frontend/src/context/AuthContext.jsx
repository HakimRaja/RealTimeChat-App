import { createContext,useCallback,useState,useEffect } from "react";
import { baseUrl, postRequest } from "../utils/services";

export const AuthContext = createContext();

export const AuthContextProvider = ({children}) =>{
    const [registerSuccess, setRegisterSuccess] = useState(false);
    const [user,setUser] = useState(null);
    const [registerError , setRegisterError] = useState(null);
    const [isRegisterLoading , setIsRegisterLoading] = useState(false);
    const [registerInfo,setRegisterInfo] = useState({
        name: "",
        email: "",
        password: "",
    })
    const [loginInfo,setLoginInfo] = useState({
        email: "",
        password: "",
    })
    const [isLoginLoading , setIsLoginLoading] = useState(false);
    const [loginError , setLoginError] = useState(null);
    const [loginSuccess, setLoginSuccess] = useState(false);

    console.log("User",user)
    console.log("loginInfo",loginInfo)


    useEffect(() => {
      const user = localStorage.getItem("User");
      setUser(JSON.parse(user));
    }, []);
    
    const registerUser = useCallback(async(e)=>{
        e.preventDefault();
    setIsRegisterLoading(true);
    setRegisterError(null);
    try {
        const response = await postRequest(`${baseUrl}/users/register`, JSON.stringify(registerInfo));

        if (response.error) {
            setRegisterError(response);
        } else {
            localStorage.setItem("User", JSON.stringify(response));
            setUser(response);
            setRegisterSuccess(true);
            setRegisterInfo({ name: "", email: "", password: "" });
        }

    } catch (error) {
        setRegisterError({ error: true, message: error.message });
    } finally {
        setIsRegisterLoading(false); // ✅ Reset loading in both success and failure
    }
}, [registerInfo]);
    console.log("Register Info", registerInfo);
    const updateRegisterInfo = useCallback((info)=>{
        setRegisterInfo(info)
    },[])

    const updateLoginInfo = useCallback((info)=>{
        setLoginInfo(info);
    },[])

    const loginUser = useCallback(
     async (e) => {
        e.preventDefault();
        setIsLoginLoading(true);
        setLoginError(null)
        const response = await postRequest(`${baseUrl}/users/login`, JSON.stringify(loginInfo));

        if (response.error) {
            setLoginError(response);
        } else {
            localStorage.setItem("User", JSON.stringify(response));
            setUser(response);
            setLoginSuccess(true);
            setLoginInfo({ name: "", email: "", password: "" });
        }
        setIsLoginLoading(false);
      },
      [loginInfo],
    )
    

    const logoutUser = useCallback(()=>{
        localStorage.removeItem("User");
        setUser(null)
    },[]);

    return <AuthContext.Provider value={{user, registerInfo, updateRegisterInfo,registerUser , registerError , isRegisterLoading , registerSuccess , logoutUser, loginUser , loginError,loginInfo,updateLoginInfo,isLoginLoading, loginSuccess}}>
            {children}
    </AuthContext.Provider>
}